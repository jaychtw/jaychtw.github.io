# Possibility — Stage A.2 revision 2

Local interactive art-direction prototype only. No installation or build is needed to run it; use Python 3 (`py` on Windows).

1. Extract the entire ZIP.
2. In the extracted Possibility-Stage-A2-Revision-2 folder, run: python3 serve.py
3. Open http://localhost:8766/ in your local browser. The first full-viewport section is the living sunlight scene. Scroll normally to discover the white portfolio below it; no click or scroll snapping is required.
4. Open http://localhost:8766/games/ for the direct portfolio. Its wordmark returns to the landing.
5. Watch the normal animation for 20–30 seconds: broad window edges gently distort, the shadow drifts, and the illumination fluctuates slowly. The title never animates.
6. Enable OS/browser Reduce Motion and reload for a stable still scene; ordinary scrolling continues to work.
7. Stop with Ctrl+C. If port 8766 is occupied, run python3 serve.py --port 8767 and replace 8766 in the URLs.

Optional comparisons:
http://localhost:8766/?light=diffuse&pattern=drift
http://localhost:8766/?light=window&pattern=cadence
http://localhost:8766/games/?pattern=cadence

Default: Window light + Drift. The only landing text is Possibility and jay.yc.chen@gmail.com. A small static downward arrow is an optional accessible in-page shortcut, not a navigation requirement. The white portfolio contains only four genuine square gameplay screenshots and their linked titles. No invented work, descriptions, menus, controls, external visual services, API keys or deployment scripts.

Asset origins/crop/checksum records are in asset-provenance.json. The original source images are not required to run the ZIP. Gallery links leave this local prototype for independently hosted public games.

Visual approval is pending. This is not full Stage B, release approval, or permission to deploy the site or modify another repository.
